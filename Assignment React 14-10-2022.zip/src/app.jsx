import HomeComp from "./component/home.component";

let App =()=>{
    return <div>
        <h1 className="header">Avengers Store</h1>
        <HomeComp/>
    </div>
}
export default App;