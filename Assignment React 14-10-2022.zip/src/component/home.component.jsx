import { useEffect } from "react"
import axios from "axios";
import { useState } from "react";
import "./mystyle.css"
 
let HomeComp = ()=>{
    let [hero, setHeroes] = useState([]);
    // let [nhero, createHero] = useState({ title : '', firstname : '', lastname : ''});
    // let [ehero, modifyHero] = useState({ _id:'', title : '', firstname : '', lastname : ''});
    // let [toggle, toggleHandler] = useState(false);
    let [carthero, modifyCart] = useState({ _id:'', hero : '', name : '', price : 0 , quantity:0, instock:true });
    let [qty,updateQty] = useState(0);

    let refresh = ()=>{
        axios.get("http://localhost:2525/data").then(res => {
            setHeroes(res.data);
        })
    }
    useEffect(function(){
       refresh();
    },[]);

    let clickHandler=(evt)=>{
        updateQty({...carthero, quantity:evt.target.value})
    }

    let AddCart=(hid)=>{
        axios.get("http://localhost:2525/gdata/"+hid).then(res => {
            modifyCart(res.data);
        })
            .catch((err)=>{
                console.log("Error",err);
            }) 
    }
    return <div>
                
            <div id="ubox">{
                        hero.map((hero, idx) =>{
                            
                            return <div key={hero._id} className="box">
                                Title : {hero.hero} <br />
                                price : {hero.price} <br />
                                instock:{hero.instock}
                                Quantity <br />
                                <input onChange={(evt)=>{clickHandler(evt)}} type="number" /> &nbsp; &nbsp; 
                                <button onClick={()=>{AddCart(hero._id)}}>Add to cart</button>
                                {/* {console.log(hero._id)} */}
                            </div>
                        })
                    }
                    </div>    
                    <div id="cart">
                        name:{carthero.hero} &nbsp; Quantity:{qty.quantity} &nbsp; <h6>price :{carthero.price*Number(qty.quantity)} </h6><br />
                        <button>buy now</button>
                   </div>  
            </div>
}
 
export default HomeComp; 