import { useParams } from "react-router-dom"
import data from "./heroes data.json"
let DetailsComp = ()=>{
    let prms = useParams();
    return <div> 
    
        <h1>Details </h1>
        {
            data.heroes.map((val,idx)=>{
                if(val.id === prms.id){
                    return <div>
                            <ul>
                            <h3>
                            <h1>Name : {val.name} <br /></h1>
                            <h2>Power Stats</h2>
                            combat power : {val.powerstats.combat} <br />
                            intelligence power : {val.powerstats.intelligence} <br />
                            power : {val.powerstats.power} <br />
                            strength : {val.powerstats.strength} <br />
                            <h2>Biography</h2>
                            full-name : {val.biography["full-name"]} <br />
                            publisher: {val.biography.publisher} <br />
                            release-date: {val.biography["release-date"]} <br />
                            budget : {val.biography.budget} <br />
                            <h2>Appearance</h2>
                            gender : {val.appearance.gender} <br />
                            race : {val.appearance.race} <br />
                            weight : {val.appearance.weight[1]} <br/>
                            </h3>
                            </ul>
                    </div>
                }
            })
        }

    </div>
}
export default DetailsComp;