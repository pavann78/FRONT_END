//ASSIGNMENT 1

// import { StyleSheet, Text, View } from "react-native";

// const Flex = () => {
//   return (
//     <View style={[styles.container, {
//       // Try setting `flexDirection` to `"row"`.
//       flexDirection: "column"
//     }]}>
//       <View style={{ flex: 1, backgroundColor: "#EED2CC" }} />
//       <View style={{ flex: 2, backgroundColor: "#6C9A8B" }} />
//       <View style={{ flex: 3, backgroundColor: "#E8998D" }} />
//     </View>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     padding: 20,
//   },
// });

// export default Flex;

//ASSIGNMENT 2

// import { useState } from "react";
// import { StyleSheet, Text, View, Platform, Pressable, Button } from "react-native";
 
// export default function App(){
//   let [colors, setColor] = useState("");
//   return (
//     <View style={[styles.container, {
//       float : "left",
//       flexDirection : "row"
 
  
//     }]}>
//       <View style={{ width : 412, height : 750, backgroundColor: colors }}></View>
//       <Pressable onPress={()=>setColor("#A1A6B4")}>
//       <View style={{ width : 102.82, height :102.82, backgroundColor: "#A1A6B4" }} />
//       </Pressable>
//       <Pressable onPress={()=>setColor("#94C5CC")}>
//       <View style={{ width : 102.82, height :102.82, backgroundColor: "#94C5CC" }} />
//       </Pressable>
//       <Pressable onPress={()=>setColor("#B4D2E7")}>
//       <View style={{ width : 102.82, height :102.82, backgroundColor: "#B4D2E7" }} />
//       </Pressable>
//       <Pressable onPress={()=>setColor("#e7dbeb")}>
//       <View style={{ width : 102.82, height :102.82, backgroundColor: "#e7dbeb" }} />
//       </Pressable>
      
//     </View>
    
//   );
// };
 
// const styles = StyleSheet.create({
//   container: {
//     display : "flex",
//     paddingTop : Platform.OS === "android" && 45 || Platform.OS === "ios" && 33,
//     flexWrap : "wrap"
//   }
// });


///--------------------------------------------------

//ASSIGNMENT 3

import { useState } from "react";
import ironman from "./assets/images/ironman.jpg"
import spiderman from "./assets/images/spiderman.jpg"
import blackpanther from "./assets/images/blackpanther.jpg"
import thor from "./assets/images/thor.jpg"
import { Button, Text,View,StyleSheet, Platform,Image } from "react-native";
export default function App(){

  let [name,updateName] = useState({title:'',firstname:'',lastname:'',image:''})
  let changeImage=( img )=>{
    if(img ==="ironman"){
      updateName({
        title:"Ironman",
        firstname:"Tony",
        lastname:"Stark",
        image:ironman
      })
    }
    else if(img ==="thor"){
       updateName({
        title:"Thor",
        firstname:"Thor",
        lastname:"Odinson",
        image:thor
      })
    }
    else if(img ==="blackpanther"){
      updateName({
        title:"Blackpanther",
        firstname:"T",
        lastname:"Challa",
        image:blackpanther
      })
    }
    else{
      updateName({
        title:"Spiderman",
        firstname:"Peter",
        lastname:"Parker",
        image:spiderman
      })
    }
  }
  return(    
    <View style={mystyle.viewstyle}>

      <View>
        <Text style={{fontSize:42, color: "purple"}}>Avengers</Text>
      </View>
      <Text/>

      <View>

        <Text style={{fontSize:22}}>
        Title : {name.title}{"\n"}  
        Firstname: {name.firstname}{"\n"}
        Lastname: {name.lastname}</Text>
        <Image source={name.image}></Image>


      <View >
        <Button onPress={()=>changeImage("thor")} title="Thor"></Button>
        <Text></Text>
        <Button onPress={()=>changeImage("blackpanther")} title="blackpanther"></Button>
        <Text></Text>
      </View>
      <View >
        <Button onPress={()=>changeImage("ironman")} title="Ironman"></Button> 
        <Text></Text>
        <Button onPress={()=>changeImage("spiderman")} title="spiderman"></Button>
        <Text></Text>
        <Text/>
      </View>


      </View>

     </View>
   
  )
}
let mystyle = StyleSheet.create({
  viewstyle:{
    flex:1,justifyContent:'center',alignItems:'center',paddingTop: Platform.OS ==="android"?30:0
  }
})